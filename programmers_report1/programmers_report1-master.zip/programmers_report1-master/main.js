import App from "./src/app.js";

new App(document.querySelector('.App'));
