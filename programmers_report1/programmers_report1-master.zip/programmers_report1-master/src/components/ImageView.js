const IMAGE_PATH_PREFIX =
  "https://fe-dev-matching-2021-03-serverlessdeploymentbuck-t3kpj3way537.s3.ap-northeast-2.amazonaws.com/public";

class ImageView {
  $target = null;
  state = null;
  constructor({ $app, initialState }) {
    this.state = initialState;

    this.$target = document.createElement("div");
    this.$target.className = "Modal ImageView";
    $app.appendChild(this.$target);

    this.render();
  }

  setState = (nextState) => {
    this.state = nextState;
    this.render();
  };

  render = () => {
    this.$target.innerHTML = `
            <div class="content">
                ${
                  this.state.selectedFilePath
                    ? `<img src="${IMAGE_PATH_PREFIX}${this.state.selectedFilePath}" />`
                    : ""
                }
            </div>
        `;
    if (!this.state.isVisible) {
      this.$target.style.display = "none";
    } else {
      this.$target.style.display = "block";
      this.$target.addEventListener("click", (e) => {
        if (e.target.tagName !== "IMG") {
          this.state = null;
          this.$target.style = "display: none";
        }
      });
      window.addEventListener("keyup", (e) => {
        if (e.keyCode == 27) {
          this.state = null;
          this.$target.style = "display: none";
        }
      });
    }
  };
}

export default ImageView;